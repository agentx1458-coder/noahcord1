import { useParams, useSearchParams } from "react-router-dom";
import { Shield, CheckCircle, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";

const Verify = () => {
  const { serverSlug } = useParams();
  const [searchParams] = useSearchParams();
  const success = searchParams.get("success");
  const error = searchParams.get("error");

  const serverName = serverSlug
    ? serverSlug.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase())
    : "Snowy Studios";

  const handleVerify = () => {
    // We need the guild_id. For now we pass slug and the callback will handle it.
    // The state parameter carries guild_id:slug
    // We'll need to fetch guild_id from the slug first
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    const redirectUri = encodeURIComponent(`${supabaseUrl}/functions/v1/discord-callback`);
    const clientId = "1475479704730472529";
    const scope = encodeURIComponent("identify guilds.join");
    
    // Fetch guild_id from slug, then redirect
    fetch(`${supabaseUrl}/functions/v1/discord-api?action=servers`, {
      headers: { "Content-Type": "application/json" },
    })
      .then(r => r.json())
      .then(servers => {
        const server = servers?.find((s: any) => s.slug === serverSlug);
        const guildId = server?.guild_id || "unknown";
        const state = encodeURIComponent(`${guildId}:${serverSlug || "default"}`);
        const oauthUrl = `https://discord.com/api/oauth2/authorize?client_id=${clientId}&redirect_uri=${redirectUri}&response_type=code&scope=${scope}&state=${state}`;
        window.location.href = oauthUrl;
      })
      .catch(() => {
        // Fallback - try with slug as state
        const state = encodeURIComponent(`unknown:${serverSlug || "default"}`);
        const oauthUrl = `https://discord.com/api/oauth2/authorize?client_id=${clientId}&redirect_uri=${redirectUri}&response_type=code&scope=${scope}&state=${state}`;
        window.location.href = oauthUrl;
      });
  };

  if (success) {
    return (
      <div className="min-h-screen gradient-bg flex items-center justify-center p-4">
        <div className="glass-card rounded-2xl p-8 w-full max-w-md text-center animate-fade-in">
          <div className="w-16 h-16 rounded-full gradient-primary flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-8 h-8 text-primary-foreground" />
          </div>
          <h1 className="text-2xl font-display font-bold text-foreground mb-2">Verified!</h1>
          <p className="text-muted-foreground text-sm">
            Your membership has been backed up successfully. You can close this page.
          </p>
        </div>
      </div>
    );
  }

  if (error) {
    const errorMessages: Record<string, string> = {
      alt_detected: "Alt account detected. You cannot verify with this account.",
      token_failed: "Authentication failed. Please try again.",
      user_fetch_failed: "Could not fetch your Discord info. Please try again.",
      unknown: "Something went wrong. Please try again.",
    };

    return (
      <div className="min-h-screen gradient-bg flex items-center justify-center p-4">
        <div className="glass-card rounded-2xl p-8 w-full max-w-md text-center animate-fade-in">
          <div className="w-16 h-16 rounded-full bg-destructive/20 flex items-center justify-center mx-auto mb-6">
            <AlertTriangle className="w-8 h-8 text-destructive" />
          </div>
          <h1 className="text-2xl font-display font-bold text-foreground mb-2">Verification Failed</h1>
          <p className="text-muted-foreground text-sm mb-6">
            {errorMessages[error] || errorMessages.unknown}
          </p>
          <Button
            onClick={() => window.location.href = window.location.pathname}
            className="gradient-primary text-primary-foreground font-semibold hover:opacity-90"
          >
            Try Again
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen gradient-bg flex items-center justify-center p-4">
      <div className="glass-card rounded-2xl p-8 w-full max-w-md text-center animate-fade-in">
        <div className="w-16 h-16 rounded-full bg-secondary flex items-center justify-center mx-auto mb-6">
          <Shield className="w-8 h-8 text-muted-foreground" />
        </div>

        <h1 className="text-2xl font-display font-bold text-foreground mb-2">{serverName}</h1>
        <p className="text-muted-foreground text-sm mb-8">
          Click the button below to verify and back up your membership.
        </p>

        <Button
          onClick={handleVerify}
          className="w-full gradient-primary text-primary-foreground font-semibold py-6 text-base hover:opacity-90 transition-opacity glow-primary"
        >
          <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24" fill="currentColor">
            <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03z" />
          </svg>
          Verify
        </Button>

        <p className="text-muted-foreground text-xs mt-6">
          By verifying, you authorize this service to back up your Discord membership. Your IP address will be collected for alt detection purposes.
        </p>
      </div>
    </div>
  );
};

export default Verify;
